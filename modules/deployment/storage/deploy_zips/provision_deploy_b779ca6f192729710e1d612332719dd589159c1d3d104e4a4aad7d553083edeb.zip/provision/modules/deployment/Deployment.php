<?php

require_once __DIR__ . "/../event/Emits_events.php";

class Deployment extends Trongate
{
  use Emits_events;

  private const RUNNING_STALE_SECONDS = 120;
  private const ZIP_RETENTION_SECONDS = 604800;

  function index(): void
  {
    $customer = $this->_require_customer();

    $data = [
      "view_module" => "deployment",
      "view_file" => "index",
      "page_title" => "Deployments",
      "current_email" => $customer->email,
      "deployments" => $this->model->all((int) $customer->id),
      "additional_includes_top" => ["deployment_module/css/deployment.css"],
    ];

    $this->module("templates");
    $this->templates->customer($data);
  }

  function create(): void
  {
    $customer = $this->_require_customer();

    if (post('submit', true) === 'Create Deployment') {
      $source_type = post("source_type", true) === "zip" ? "zip" : "git";
      $this->validation->set_rules("server_id", "server", "required");
      $this->validation->set_rules("environment_id", "environment", "required");
      if ($source_type === "git") {
        $this->validation->set_rules(
          "repo_url",
          "repo URL",
          "required|max_length[500]",
        );
        $this->validation->set_rules(
          "branch",
          "branch",
          "required|max_length[100]",
        );
      }

      if ($this->validation->run() === true) {
        $server_id = (int) post("server_id");
        $environment_id = (int) post("environment_id");
        $this->module("server");
        $this->module("environment");
        $server_ok =
          $this->server->model->get($server_id, (int) $customer->id) !== false;
        $env_ok =
          $this->environment->model->get(
            $environment_id,
            (int) $customer->id,
          ) !== false;

        $lock_name = "";

        if (!$server_ok || !$env_ok) {
          $_SESSION["flash_error"] = "Invalid server or environment.";
        } elseif (
          !$this->_env_server_allowed(
            $environment_id,
            $server_id,
            (int) $customer->id,
            $lock_name,
          )
        ) {
          $_SESSION[
            "flash_error"
          ] = "Environment is already deployed to \"{$lock_name}\". Each environment is locked to one server.";
        } else {
          $zip_path = null;
          if ($source_type === "zip") {
            $zip_path = $this->_store_zip();
            if ($zip_path === false) {
              $_SESSION["flash_error"] = "Zip upload failed or missing.";
              goto render_create;
            }
          } elseif ($source_type === "git") {
            // Attempt to pull release zip from GitHub/GitLab.
            // On failure, zip_path stays null → remote falls back to git clone.
            $zip_path = $this->_fetch_zip_from_provider(
              (string) post("repo_url", true),
              (string) post("branch", true),
            ) ?: null;
          }

          $selected_script = false;
          $selected_script_id = (int) post("custom_script_id");
          if ($selected_script_id > 0) {
            $this->module("script");
            $selected_script = $this->script->model->get($selected_script_id, (int) $customer->id);
            if ($selected_script === false || $selected_script->type !== "deploy") {
              $selected_script = false;
              $selected_script_id = 0;
            }
          }

          $id = $this->model->create([
            "server_id" => $server_id,
            "environment_id" => $environment_id,
            "customer_id" => (int) $customer->id,
            "script_id" => $selected_script !== false ? $selected_script_id : null,
            "source_type" => $source_type,
            "repo_url" =>
              $source_type === "git" ? post("repo_url", true) : null,
            "branch" => $source_type === "git" ? post("branch", true) : null,
            "zip_path" => $zip_path,
            "status" => "script_ready",
          ]);

          $custom_script_id = $selected_script !== false ? $selected_script_id : null;
          $default_script = $this->_default_deploy_script_template();
          $base_script = $selected_script !== false ? (string) $selected_script->body : $default_script;
          $submitted_script = (string) (post("deploy_script_body") ?: "");
          if (
            trim($submitted_script) !== "" &&
            $this->_normalize_script_body($submitted_script) !== $this->_normalize_script_body($base_script)
          ) {
            $this->module("script");
            $custom_script_id = $this->script->model->create([
              "customer_id" => (int) $customer->id,
              "name" => "Deployment {$id} custom deploy script",
              "description" => "Created from deployment wizard edits.",
              "type" => "deploy",
              "body" => $submitted_script,
            ]);

            if ($custom_script_id !== false) {
              $this->model->assign_script((int) $id, (int) $customer->id, (int) $custom_script_id);
              $this->_emit("ScriptCreated", "script", (int) $custom_script_id, [
                "name" => "Deployment {$id} custom deploy script",
                "type" => "deploy",
              ]);
              $this->_emit("DeploymentScriptChanged", "deployment", (int) $id, [
                "script_id" => (int) $custom_script_id,
              ]);
            }
          }

          $this->_emit("DeploymentCreated", "deployment", (int) $id, [
            "server_id" => $server_id,
            "environment_id" => $environment_id,
            "source_type" => $source_type,
            "status" => "script_ready",
          ]);
          $_SESSION["flash_success"] =
            $custom_script_id
              ? "Deployment created with custom deploy script. Staging will start automatically."
              : "Deployment created. Staging will start automatically.";
          redirect("deployment/create/" . $id);
          return;
        }
      }
    }

    render_create:

    $wizard_id = (int) segment(3);
    $wizard_deployment = false;
    if ($wizard_id > 0 && post('submit', true) !== 'Create Deployment') {
      $wizard_deployment = $this->model->get($wizard_id, (int) $customer->id);
      if ($wizard_deployment === false) {
        redirect("deployment/create");
        return;
      }
    }

    $preselected_server = (int) ($_GET["server"] ?? 0);
    $preselected_env = (int) ($_GET["env"] ?? 0);
    $this->module("script");
    $deploy_scripts = $this->script->model->by_type((int) $customer->id, "deploy");

    $preselected_script = false;
    $preselected_script_id = (int) (post("custom_script_id") ?: ($_GET["script"] ?? 0));
    if ($preselected_script_id > 0) {
      $preselected_script = $this->script->model->get($preselected_script_id, (int) $customer->id);
      if ($preselected_script === false || $preselected_script->type !== "deploy") {
        $preselected_script = false;
      }
    }

    $data = [
      "view_module" => "deployment",
      "view_file" => "create",
      "page_title" => "New Deployment",
      "current_email" => $customer->email,
      "form_location" => "deployment/create",
      "servers" => $this->model->servers_for_customer((int) $customer->id),
      "environments" => $this->model->environments_for_customer(
        (int) $customer->id,
      ),
      "deployment" => $wizard_deployment,
      "preselected_server" => $preselected_server,
      "preselected_env" => $preselected_env,
      "preselected_script" => $preselected_script,
      "deploy_scripts" => $deploy_scripts,
    ];

    $this->view("create", $data);
  }

  function show(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $deployment = $this->model->get($id, (int) $customer->id);
    if ($deployment === false) {
      redirect("deployment");
    }

    $script = $this->_render_deploy_script($deployment);
    $display_script = $this->_redact_deploy_script($script, $deployment);

    $this->module("environment-services");
    $services = $this->services->model->by_environment(
      (int) $deployment->env_id,
      (int) $customer->id,
    );
    $this->module("server-health");
    $latest_health = $this->health->model->latest("deployment", $id);

    $this->module("event");
    $recent_events = $this->event->model->recent_for_entity(
      "deployment",
      $id,
      (int) $customer->id,
      5,
    );

    $this->module("script");
    $deploy_scripts = $this->script->model->by_type((int) $customer->id, "deploy");

    $data = [
      "view_module" => "deployment",
      "view_file" => "show",
      "page_title" => "Deployment #" . $id,
      "current_email" => $customer->email,
      "deployment" => $deployment,
      "deploy_script" => $display_script,
      "deploy_scripts" => $deploy_scripts,
      "services" => $services,
      "latest_health" => $latest_health,
      "recent_events" => $recent_events,
      "additional_includes_top" => ["deployment_module/css/deployment.css"],
    ];

    $this->module("templates");
    $this->templates->customer($data);
  }

  function stream(): void
  {
    $id = (int) segment(3);
    $this->module("stream");
    $this->stream->start();
    $this->module("ssh");
    $emit = function (string $line, string $event = ""): void {
      $this->stream->emit($line, $event);
    };

    $this->module("trongate_tokens");
    $token = $this->trongate_tokens->attempt_get_valid_token(
      Customer::CUSTOMER_LEVEL,
    );
    if ($token === false) {
      http_response_code(401);
      $emit("Unauthorized.");
      $this->stream->done(["status" => "failed"]);
      exit();
    }
    $this->module("customer");
    $customer = $this->customer->model->_get_current_customer();

    if ($customer === false) {
      http_response_code(401);
      $emit("Unauthorized.");
      $this->stream->done(["status" => "failed"]);
      exit();
    }

    $d = $this->model->get($id, (int) $customer->id);
    if ($d === false) {
      http_response_code(404);
      $emit("Deployment not found.");
      $this->stream->done(["status" => "failed"]);
      exit();
    }

    $is_onboarding_deployment = (int) ($customer->onboarding_server_id ?? 0) === (int) $d->server_id;
    if (empty($customer->onboarded_at) && !$is_onboarding_deployment) {
      http_response_code(401);
      $emit("Unauthorized for this onboarding deployment.");
      $this->stream->done(["status" => "failed"]);
      exit();
    }

    if (!defined("RUNNER_SSH_KEY") || !RUNNER_SSH_KEY) {
      http_response_code(503);
      $emit("RUNNER_SSH_KEY is not configured.");
      $this->stream->done(["status" => "failed"]);
      exit();
    }

    $this->stream->prepare_long_running();

    $user = $d->ssh_user ?: "root";
    $port = (int) ($d->ssh_port ?: 22);

    // Validate before touching DB state
    if (!filter_var($d->ip_address, FILTER_VALIDATE_IP)) {
      $emit("Invalid server IP address.");
      $this->stream->done(["status" => "failed", "sha" => null]);
      return;
    }
    if (!preg_match('/^[a-z_][a-z0-9_.-]{0,31}$/i', $user)) {
      $emit("Invalid SSH user.");
      $this->stream->done(["status" => "failed", "sha" => null]);
      return;
    }

    if ($d->status === "running") {
      $this->_wait_for_running_deployment($id, (int) $customer->id, $emit);
      return;
    }

    $this->model->mark_running($id);
    $this->_emit("DeploymentStarted", "deployment", $id, [
      "source" => "stream",
    ]);

    $script = $this->_render_deploy_script($d);

    // SCP zip if a zip_path is present (uploaded zip or provider-fetched zip)
    if (($d->source_type ?? "") === "zip" && empty($d->zip_path)) {
      $msg = "Deployment zip is missing from storage. Upload the zip again to retry.";
      $emit($msg);
      $this->stream->done(["status" => "missing_zip", "sha" => null]);
      $this->model->finish($id, "failed", $msg, null);
      return;
    }

    if (!empty($d->zip_path) && file_exists($d->zip_path)) {
      $remote_zip = "/tmp/provision_deploy_" . $id . "_" . time() . ".zip";
      $emit("Uploading application zip…");
      $scp_result = $this->ssh->scp_upload($d->zip_path, $d->ip_address, $user, $port, $remote_zip);
      if (!$scp_result['success']) {
        $msg = "SCP failed: " . $scp_result['output'];
        $emit($msg);
        $this->stream->done(["status" => "failed", "sha" => null]);
        $this->model->finish($id, "failed", $msg, null);
        $this->_emit("DeploymentFailed", "deployment", $id, [
          "reason" => "scp_failed",
        ]);
        return;
      }
      $emit("Zip uploaded to {$remote_zip}");
      $script =
        "export DEPLOY_ZIP='" .
        str_replace("'", "'\\''", $remote_zip) .
        "'\n" .
        $script;
    } elseif (($d->source_type ?? "") === "zip") {
      $msg = "Deployment zip was removed from storage. Upload the zip again to retry.";
      $emit($msg);
      $this->stream->done(["status" => "missing_zip", "sha" => null]);
      $this->model->finish($id, "failed", $msg, null);
      return;
    }

    $log  = '';
    $exit_code = $this->ssh->execute_script(
      $d->ip_address,
      $user,
      $port,
      $script,
      function (string $line) use (&$log, $emit): void {
        $log .= $line . "\n";
        $emit($line);
      },
      fn() => $this->stream->ping(),
      RUNNER_SCRIPT_TIMEOUT,
    );
    $log = trim($log);

    $sha = null;
    if (preg_match_all("/SHA\s*:\s*([0-9a-f]{7,40})\b/i", $log, $m)) {
      $sha = strtolower(end($m[1]));
    }
    $release_path = null;
    if (preg_match_all("/RELEASE_PATH\s*:\s*(\S+)/i", $log, $m)) {
      $release_path = end($m[1]);
    }

    $status = $exit_code === 0 ? "staged" : "failed";
    try {
      $this->model->finish($id, $status, $log, $sha, $release_path);
    } catch (Throwable $e) {
      $message = "Deployment finished remotely, but Provision could not save the staged release metadata: " . $e->getMessage();
      $emit($message);
      try {
        $this->model->mark_stale_running_failed($id, (int) $customer->id, $message);
      } catch (Throwable) {
      }
      $this->stream->done(["status" => "failed", "sha" => $sha, "release_path" => $release_path]);
      return;
    }

    if ($status === "staged") {
      if (!empty($d->zip_path) && file_exists($d->zip_path)) {
        @unlink($d->zip_path);
      }
      $this->_emit("DeploymentSucceeded", "deployment", $id, [
        "sha" => $sha,
        "release_path" => $release_path,
        "source" => "stream",
      ]);
    } else {
      $this->_emit("DeploymentFailed", "deployment", $id, [
        "exit_code" => $exit_code,
        "source" => "stream",
      ]);
    }

    $this->stream->done(["status" => $status, "sha" => $sha, "release_path" => $release_path]);
  }

  private function _wait_for_running_deployment(int $id, int $customer_id, callable $emit): void
  {
    $stale_after = self::RUNNING_STALE_SECONDS;
    $current = $this->model->get($id, $customer_id);
    if ($current === false) {
      $emit("Deployment not found.");
      $this->stream->done(["status" => "failed", "sha" => null]);
      return;
    }

    if ($current->status !== "running") {
      $log = trim((string) ($current->run_log ?? ""));
      if ($log !== "") {
        $emit($this->_tail_text($log, 4000));
      }
      $this->stream->done([
        "status" => $current->status,
        "sha" => $current->deployed_sha ?? null,
        "release_path" => $current->release_path ?? null,
      ]);
      return;
    }

    $started_at = strtotime((string) ($current->started_at ?? ""));
    if ($started_at === false || time() - $started_at <= $stale_after) {
      $this->stream->emit(json_encode([
        "status" => "running",
        "message" => "Deployment is already running.",
      ]), "state");
      $this->stream->done(["status" => "running", "sha" => null]);
      return;
    }

    $message = "Deployment was left in running state for more than " . self::RUNNING_STALE_SECONDS . " seconds. It was marked failed so you can retry.";
    $this->model->mark_stale_running_failed($id, $customer_id, $message);
    $emit($message);
    $this->stream->done(["status" => "failed", "sha" => null]);
  }

  function assign_script(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $d = $this->model->get($id, (int) $customer->id);
    if ($d === false) {
      redirect("deployment");
    }

    $this->validation->set_rules("dummy", "dummy", "max_length[1]");
    if ($this->validation->run() !== true) {
      redirect("deployment/show/" . $id);
      return;
    }

    $script_id_raw = (int) post("script_id");
    if ($script_id_raw > 0) {
      $this->module("script");
      $script = $this->script->model->get($script_id_raw, (int) $customer->id);
      if ($script === false || $script->type !== "deploy") {
        $script_id_raw = 0;
      }
    }
    $this->model->assign_script(
      $id,
      (int) $customer->id,
      $script_id_raw > 0 ? $script_id_raw : null,
    );
    $this->_emit("DeploymentScriptChanged", "deployment", $id, [
      "script_id" => $script_id_raw > 0 ? $script_id_raw : null,
    ]);
    $_SESSION["flash_success"] =
      $script_id_raw > 0
        ? "Custom script assigned."
        : "Reverted to default generated script.";
    redirect("deployment/show/" . $id);
  }

  function reupload_zip(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $d = $this->model->get($id, (int) $customer->id);
    if ($d === false) {
      redirect("deployment");
      return;
    }

    if (($d->source_type ?? "") !== "zip") {
      $_SESSION["flash_error"] = "Only zip deployments can have their zip file replaced.";
      redirect("deployment/show/" . $id);
      return;
    }

    if ($d->status === "running") {
      $_SESSION["flash_error"] = "Cannot replace the zip while deployment is running.";
      redirect("deployment/show/" . $id);
      return;
    }

    $zip_path = $this->_store_zip();
    if ($zip_path === false) {
      $_SESSION["flash_error"] = "Zip upload failed or missing.";
      redirect("deployment/show/" . $id);
      return;
    }

    $old_path = (string) ($d->zip_path ?? "");
    $this->model->set_zip_path($id, (int) $customer->id, $zip_path);
    if ($old_path !== "" && $old_path !== $zip_path && file_exists($old_path)) {
      @unlink($old_path);
    }

    $this->_emit("DeploymentZipReuploaded", "deployment", $id, [
      "zip_path" => basename($zip_path),
    ]);
    $_SESSION["flash_success"] = "Deployment zip replaced. You can deploy again.";
    redirect("deployment/show/" . $id);
  }

  function mark_success(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $this->validation->set_rules("dummy", "dummy", "max_length[1]");
    if ($this->validation->run() !== true) {
      redirect("deployment/show/" . $id);
      return;
    }
    $d = $this->model->get($id, (int) $customer->id);
    if ($d !== false) {
      $prev_status = $d->status;
      $this->model->update_status($id, "success");
      $sha = trim(post("deployed_sha", true) ?: "");
      if (preg_match('/^[0-9a-f]{7,40}$/i', $sha)) {
        $this->model->set_deployed_sha($id, strtolower($sha));
      }
      $this->_emit("DeploymentSucceeded", "deployment", $id, [
        "previous_status" => $prev_status,
        "deployed_sha" => $sha ?: null,
      ]);
      $_SESSION["flash_success"] = "Deployment marked as successful.";
    }
    redirect("deployment/show/" . $id);
  }

  function promote_release(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $this->validation->set_rules("dummy", "dummy", "max_length[1]");
    if ($this->validation->run() !== true) {
      redirect("deployment/show/" . $id);
      return;
    }
    $result = $this->_promote_release_result($id, (int) $customer->id);
    if (!$result["ok"]) {
      $_SESSION["flash_error"] = $result["message"];
      redirect("deployment/show/" . $id);
      return;
    }

    $summary = $result["health"];
    $_SESSION["flash_success"] =
      "Release promoted. Health checks: {$summary["healthy"]} healthy, {$summary["unhealthy"]} unhealthy, {$summary["unknown"]} unknown.";
    redirect("deployment/show/" . $id);
  }

  function scan_release_sql(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $d = $this->model->get($id, (int) $customer->id);
    $this->module('http');
    if ($d === false || $d->status !== "staged" || empty($d->release_path)) {
      $this->http->json_response(["ok" => false, "message" => "Only staged releases can be scanned for SQL files."], 422);
      return;
    }

    $script = $this->_render_release_script("scan_release_sql", $d);
    $result = $this->_run_remote_script($d, $script);
    if ($result["exit_code"] !== 0) {
      $this->http->json_response([
        "ok" => false,
        "message" => "SQL scan failed: " . $this->_tail_text(trim($result["log"]), 800),
      ], 500);
      return;
    }

    $files = [];
    foreach (preg_split("/\r\n|\n|\r/", trim((string) $result["log"])) ?: [] as $line) {
      if (!str_starts_with($line, "SQL_FILE\t")) {
        continue;
      }
      $parts = explode("\t", $line, 3);
      if (count($parts) !== 3) {
        continue;
      }
      $path = base64_decode($parts[1], true);
      $sql = base64_decode($parts[2], true);
      if ($path === false || $sql === false) {
        continue;
      }
      $files[] = ["path" => $path, "sql" => $sql];
    }

    $this->http->json_response(["ok" => true, "files" => $files]);
  }

  function delete_release_sql(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $d = $this->model->get($id, (int) $customer->id);
    $this->module('http');
    if ($d === false || $d->status !== "staged" || empty($d->release_path)) {
      $this->http->json_response(["ok" => false, "message" => "Only staged releases can have SQL files deleted."], 422);
      return;
    }

    $payload = $this->http->json_request();
    $paths = is_array($payload["paths"] ?? null) ? $payload["paths"] : [];
    $clean_paths = [];
    foreach ($paths as $path) {
      if (!is_string($path)) {
        continue;
      }
      $path = str_replace("\\", "/", trim($path));
      if (
        $path === "" ||
        str_starts_with($path, "/") ||
        str_contains($path, "../") ||
        str_contains($path, "/..") ||
        $path === ".."
      ) {
        continue;
      }
      if (strtolower(pathinfo($path, PATHINFO_EXTENSION)) !== "sql") {
        continue;
      }
      $clean_paths[] = $path;
    }

    if (empty($clean_paths)) {
      $this->http->json_response(["ok" => false, "message" => "No valid SQL files were selected for deletion."], 422);
      return;
    }

    $script = $this->_render_release_script("delete_release_sql", (object) [
      "release_path" => $d->release_path,
      "sql_paths" => $clean_paths,
    ]);
    $result = $this->_run_remote_script($d, $script);
    if ($result["exit_code"] !== 0) {
      $this->http->json_response([
        "ok" => false,
        "message" => "SQL deletion failed: " . $this->_tail_text(trim($result["log"]), 800),
      ], 500);
      return;
    }

    $deleted = 0;
    if (preg_match("/DELETED_SQL_COUNT\s*:\s*(\d+)/", $result["log"], $matches)) {
      $deleted = (int) $matches[1];
    }
    $this->http->json_response(["ok" => true, "deleted" => $deleted]);
  }

  function promote_release_wizard(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $result = $this->_promote_release_result($id, (int) $customer->id);
    $this->module('http');
    $this->http->json_response($result, $result["ok"] ? 200 : 422);
  }

  function demote_release(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $this->validation->set_rules("dummy", "dummy", "max_length[1]");
    if ($this->validation->run() !== true) {
      redirect("deployment/show/" . $id);
      return;
    }
    $d = $this->model->get($id, (int) $customer->id);
    if ($d === false || $d->status !== "success" || empty($d->previous_release_path)) {
      $_SESSION["flash_error"] = "Only live deployments with a previous release can be demoted.";
      redirect("deployment/show/" . $id);
      return;
    }

    $script = $this->_render_release_script("demote_release", $d);
    $result = $this->_run_remote_script($d, $script);
    if ($result["exit_code"] !== 0) {
      $_SESSION["flash_error"] = "Demotion failed: " . $this->_tail_text(trim($result["log"]), 500);
      redirect("deployment/show/" . $id);
      return;
    }

    $this->model->demote_release($id, (int) $customer->id);
    $this->_emit("ReleaseDemoted", "deployment", $id, [
      "release_path" => $d->release_path,
      "previous_release_path" => $d->previous_release_path,
    ]);

    $summary = $this->_run_environment_health_checks($id, (int) $d->env_id, (int) $customer->id);
    $_SESSION["flash_success"] =
      "Release demoted. Health checks: {$summary["healthy"]} healthy, {$summary["unhealthy"]} unhealthy, {$summary["unknown"]} unknown.";
    redirect("deployment/show/" . $id);
  }

  function delete(): void
  {
    $id = (int) segment(3);
    $customer = $this->_require_customer();
    $this->validation->set_rules("dummy", "dummy", "max_length[1]");
    if ($this->validation->run() !== true) {
      redirect("deployment/show/" . $id);
      return;
    }
    $snap = $this->model->get($id, (int) $customer->id);
    if ($snap && !empty($snap->zip_path) && file_exists($snap->zip_path)) {
      @unlink($snap->zip_path);
    }
    $this->model->delete($id, (int) $customer->id);
    $this->_emit("DeploymentDeleted", "deployment", $id, [
      "repo_url" => $snap ? $snap->repo_url : null,
      "server_id" => $snap ? (int) $snap->server_id : null,
    ]);
    $_SESSION["flash_success"] = "Deployment deleted.";
    redirect("deployment");
  }

  private function _promote_release_result(int $id, int $customer_id): array
  {
    $d = $this->model->get($id, $customer_id);
    if ($d === false || $d->status !== "staged" || empty($d->release_path)) {
      if ($d !== false && $d->status === "staged") {
        $recovered_path = $this->_release_path_from_log((string) ($d->run_log ?? ""));
        if ($recovered_path !== null) {
          $this->model->set_release_path($id, $recovered_path);
          $d->release_path = $recovered_path;
        }
      }
      if ($d === false || $d->status !== "staged" || empty($d->release_path)) {
        return [
          "ok" => false,
          "message" => "Only staged releases with a saved release path can be promoted.",
        ];
      }
    }

    $script = $this->_render_release_script("promote_release", $d);
    $result = $this->_run_remote_script($d, $script);
    if ($result["exit_code"] !== 0) {
      return [
        "ok" => false,
        "message" => "Promotion failed: " . $this->_tail_text(trim($result["log"]), 800),
      ];
    }

    $previous_release_path = null;
    if (preg_match("/PREVIOUS_RELEASE_PATH\s*:\s*(.*)$/mi", $result["log"], $m)) {
      $previous_release_path = trim($m[1]) ?: null;
    }
    $this->model->promote_release($id, $customer_id, $previous_release_path);
    $this->_emit("ReleasePromoted", "deployment", $id, [
      "release_path" => $d->release_path,
      "previous_release_path" => $previous_release_path,
    ]);

    $health = $this->_run_environment_health_checks($id, (int) $d->env_id, $customer_id);

    return [
      "ok" => true,
      "message" => "Release promoted.",
      "release_path" => $d->release_path,
      "previous_release_path" => $previous_release_path,
      "health" => $health,
    ];
  }

  /**
   * Decrypts the deployment's env-vars and renders the bash deployment
   * script via the `scripts/deploy_script` view (returned as a string).
   */
  private function _render_deploy_script(object $d): string
  {
    $env_vars = [];
    if (!empty($d->env_variables_enc)) {
      $this->module("environment");
      $env_vars =
        $this->environment->model->decrypt_blob($d->env_variables_enc) ?: [];
    }

    if (($d->script_type ?? "") === "deploy" && trim((string) ($d->script_body ?? "")) !== "") {
      $this->module("script");
      return $this->script->model->interpolate(
        (string) $d->script_body,
        $this->_deploy_script_vars($d, $env_vars),
      );
    }

    return (string) $this->view(
      "scripts/deploy_script",
      [
        "view_module" => "deployment",
        "deployment" => $d,
        "env_vars" => $env_vars,
      ],
      true,
    );
  }

  private function _deploy_script_vars(object $d, array $env_vars): array
  {
    $source = $d->source_type ?? "git";
    if ($source === "git" && !empty($d->zip_path)) {
      $source = "zip";
    }

    $webroot = (string) ($d->web_root ?: "/var/www/html");
    $domain = (string) ($d->domain ?? "");
    $db = (string) ($d->db_name ?? "");
    $release_path = "/var/www/releases/deployment_" . (int) $d->id . "_" . date("YmdHis");

    $vars = [
      "{{PHP_VERSION}}" => (string) ($d->php_version ?? ""),
      "{{REPO_URL}}" => (string) ($d->repo_url ?? ""),
      "{{BRANCH}}" => (string) ($d->branch ?? "main"),
      "{{WEB_ROOT}}" => $webroot,
      "{{DOMAIN}}" => $domain,
      "{{DB_NAME}}" => $db,
      "{{SERVER_IP}}" => (string) ($d->ip_address ?? ""),
      "{{SERVER_NAME}}" => (string) ($d->server_name ?? ""),
      "{{ENV_NAME}}" => (string) ($d->env_name ?? ""),
      "{{ENV_VARS}}" => $this->_render_env_vars_block($env_vars),
      "{{RELEASE_PATH}}" => $release_path,
      "{{SOURCE_TYPE}}" => $source,
      "{{VHOST_BLOCK}}" => $domain !== ""
        ? $this->_render_deploy_script_partial("_vhost", [
          "domain" => $domain,
          "webroot" => $webroot,
        ])
        : "# (no domain configured)",
      "{{CONFIG_PATCH_BLOCK}}" => $this->_render_deploy_script_partial("_config_patch", [
        "deployment" => $d,
        "release_path" => $release_path,
        "db" => $db,
        "env_vars" => $env_vars,
      ]),
    ];

    foreach ($env_vars as $key => $value) {
      $safe_key = preg_replace("/[^A-Z0-9_]/", "_", strtoupper((string) $key));
      if ($safe_key === "") {
        continue;
      }
      $vars["{{{$safe_key}}}"] = (string) $value;
    }

    return $vars;
  }

  private function _render_deploy_script_partial(string $script, array $data): string
  {
    return trim((string) $this->view(
      "scripts/" . $script,
      array_merge(["view_module" => "deployment"], $data),
      true,
    ));
  }

  private function _render_env_vars_block(array $env_vars): string
  {
    return (string) $this->view(
      "scripts/_env_vars",
      [
        "view_module" => "deployment",
        "env_vars" => $env_vars,
      ],
      true,
    );
  }

  private function _default_deploy_script_template(): string
  {
    $path = __DIR__ . "/assets/deploy_script_template.txt";
    return is_file($path) ? (string) file_get_contents($path) : "";
  }

  private function _normalize_script_body(string $script): string
  {
    return trim(str_replace(["\r\n", "\r"], "\n", $script));
  }

  private function _render_release_script(string $script, object $d): string
  {
    return (string) $this->view(
      "scripts/" . $script,
      [
        "view_module" => "deployment",
        "deployment" => $d,
      ],
      true,
    );
  }

  private function _run_remote_script(object $d, string $script): array
  {
    if (!defined("RUNNER_SSH_KEY") || !RUNNER_SSH_KEY) {
      return ["exit_code" => 1, "log" => "RUNNER_SSH_KEY is not configured."];
    }

    $user = $d->ssh_user ?: "root";
    $port = (int) ($d->ssh_port ?: 22);
    if (!filter_var($d->ip_address, FILTER_VALIDATE_IP)) {
      return ["exit_code" => 1, "log" => "Invalid server IP address."];
    }
    if (!preg_match('/^[a-z_][a-z0-9_.-]{0,31}$/i', $user)) {
      return ["exit_code" => 1, "log" => "Invalid SSH user."];
    }

    $this->module("ssh");
    $log = '';
    $exit_code = $this->ssh->execute_script(
      $d->ip_address,
      $user,
      $port,
      $script,
      function (string $line) use (&$log): void {
        $log .= $line . "\n";
      },
      null,
      RUNNER_SCRIPT_TIMEOUT,
    );

    return [
      "exit_code" => $exit_code,
      "log" => trim($log),
    ];
  }

  private function _run_environment_health_checks(int $deployment_id, int $env_id, int $customer_id): array
  {
    $summary = ["healthy" => 0, "unhealthy" => 0, "unknown" => 0];
    $record = static function (?array $result) use (&$summary): void {
      $status = $result["status"] ?? "unknown";
      if (!isset($summary[$status])) {
        $status = "unknown";
      }
      $summary[$status]++;
    };

    $this->module("server-health");
    $record($this->health->check_deployment_result($deployment_id, $customer_id));

    $this->module("environment-services");
    $services = $this->services->model->by_environment($env_id, $customer_id);
    foreach ($services as $service) {
      $record($this->health->check_service_result((int) $service->id, $customer_id));
    }

    return $summary;
  }

  /**
   * Removes secret values from the script preview shown in the browser.
   * The stream deploy path renders a fresh unredacted script server-side.
   */
  private function _redact_deploy_script(string $script, ?object $d = null): string
  {
    $lines = preg_split("/\r\n|\n|\r/", $script);
    if ($lines === false) {
      return $script;
    }

    $redacted = [];
    foreach ($lines as $line) {
      if (preg_match('/^export\s+([A-Z0-9_]+)=/', $line, $matches) === 1) {
        $key = $matches[1];
        if ($this->_is_sensitive_script_key($key)) {
          $redacted[] = "export {$key}='[redacted]'";
          continue;
        }
      }

      $line = preg_replace(
        "/^(\\s*'(?:user|password)'\\s*=>\\s*)'[^']*'(,?\\s*)$/",
        "$1'[redacted]'$2",
        $line,
      );
      $redacted[] = $line ?? "";
    }

    $redacted_script = implode("\n", $redacted);

    if ($d !== null && !empty($d->env_variables_enc)) {
      $this->module("environment");
      $env_vars = $this->environment->model->decrypt_blob($d->env_variables_enc) ?: [];
      foreach ($env_vars as $key => $value) {
        $value = (string) $value;
        if ($value === "" || !$this->_is_sensitive_script_key(strtoupper((string) $key))) {
          continue;
        }
        $redacted_script = str_replace($value, "[redacted]", $redacted_script);
      }
    }

    return $redacted_script;
  }

  private function _is_sensitive_script_key(string $key): bool
  {
    if ($key === "DB_USER") {
      return true;
    }

    return preg_match(
      '/(?:PASSWORD|PASS|SECRET|TOKEN|PRIVATE_KEY|API_KEY|ACCESS_KEY)/',
      $key,
    ) === 1;
  }

  private function _tail_text(string $message, int $length): string
  {
    return strlen($message) > $length ? "..." . substr($message, -$length) : $message;
  }

  private function _release_path_from_log(string $log): ?string
  {
    if (preg_match_all("/RELEASE_PATH\s*:\s*(\S+)/i", $log, $matches)) {
      $path = trim((string) end($matches[1]));
      return $path !== "" ? $path : null;
    }
    return null;
  }

  private function _env_server_allowed(
    int $env_id,
    int $server_id,
    int $customer_id,
    string &$locked_name,
  ): bool {
    $rows = $this->db->query_bind(
      "SELECT d.server_id, s.name FROM deployment d
             JOIN server s ON s.id = d.server_id
             WHERE d.environment_id = :eid AND d.customer_id = :cid LIMIT 1",
      ["eid" => $env_id, "cid" => $customer_id],
      "object",
    );
    if (empty($rows)) {
      return true;
    }
    $locked_name = $rows[0]->name;
    return (int) $rows[0]->server_id === $server_id;
  }

  private function _store_zip(): string|false
  {
    $this->_prune_zip_storage();

    if (
      empty($_FILES["zip_file"]["tmp_name"]) ||
      $_FILES["zip_file"]["error"] !== UPLOAD_ERR_OK
    ) {
      return false;
    }
    if (
      strtolower(pathinfo($_FILES["zip_file"]["name"], PATHINFO_EXTENSION)) !==
      "zip"
    ) {
      return false;
    }
    $hash = hash_file("sha256", $_FILES["zip_file"]["tmp_name"]);
    if ($hash === false) {
      return false;
    }
    $this->module("storage");
    $dir = $this->storage->ensure_dir("deploy_zips");
    if ($dir === false) {
      return false;
    }
    $dest = $dir . DIRECTORY_SEPARATOR . "provision_deploy_" . $hash . ".zip";
    if (!move_uploaded_file($_FILES["zip_file"]["tmp_name"], $dest)) {
      return false;
    }
    return $dest;
  }

  private function _prune_zip_storage(): void
  {
    $this->module("storage");
    if (!is_dir($this->storage->path("deploy_zips"))) {
      return;
    }

    $keep = [];
    $rows = $this->db->query_bind(
      "SELECT zip_path FROM deployment WHERE zip_path IS NOT NULL AND status IN ('script_ready','running','failed')",
      [],
      "object",
    );
    foreach ($rows as $row) {
      $keep[(string) $row->zip_path] = true;
    }

    foreach ($this->storage->glob("deploy_zips/*.zip") as $file) {
      if (isset($keep[$file])) {
        continue;
      }
      $mtime = filemtime($file);
      if ($mtime !== false && time() - $mtime > self::ZIP_RETENTION_SECONDS) {
        @unlink($file);
      }
    }
  }

  private function _require_customer(): object
  {
    $this->module("customer");
    $this->customer->_require_onboarded();
    return $this->customer->_require_customer();
  }

  private function _get_provider_archive_url(string $repo_url, string $branch): string|false
  {
    $b = rawurlencode($branch);
    if (preg_match('#(?:https?://|git@)github\.com[:/](.+?)(?:\.git)?/?$#i', $repo_url, $m)) {
      return 'https://github.com/' . trim($m[1], '/') . '/archive/refs/heads/' . $b . '.zip';
    }
    if (preg_match('#(?:https?://|git@)gitlab\.com[:/](.+?)(?:\.git)?/?$#i', $repo_url, $m)) {
      $slug = trim($m[1], '/');
      $name = basename($slug);
      return "https://gitlab.com/{$slug}/-/archive/{$b}/{$name}-{$b}.zip";
    }
    return false;
  }

  private function _fetch_zip_from_provider(string $repo_url, string $branch): string|false
  {
    $this->_prune_zip_storage();

    $archive_url = $this->_get_provider_archive_url($repo_url, $branch);
    if ($archive_url === false) {
      return false;
    }

    $this->module('http-client');
    try {
      $result = $this->client->fetch($archive_url);
    } catch (Client_Error $e) {
      return false;
    }

    if ($result['status'] !== 200 || strlen($result['body']) < 100) {
      return false;
    }
    if (strncmp($result['body'], "PK\x03\x04", 4) !== 0) {
      return false;
    }
    $data = $result['body'];

    $this->module("storage");
    return $this->storage->put('deploy_zips/provision_deploy_' . hash('sha256', $data) . '.zip', $data);
  }
}
